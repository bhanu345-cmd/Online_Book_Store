import React from 'react';
import everybook from '../Images/EveryBook.jpg';
import sofaBook from '../Images/SofaAndBook.jpg';
import chetan from '../Images/ChetanBhagat.jpg';
import jkrowling from '../Images/JkRowling.jpg';
import pauloCoelho from '../Images/PauloCoelho.jpg';
import bookGenres from '../Images/book-genres.jpg';
import science from '../Images/science.jpg';
import webd from '../Images/web-development.jpg';
import './Banner.css';
export default class Banner extends React.Component{
    render(){
        return(
            <>
            <div className="row mt-3">
                <div className="col-lg-6 col-md-6 col-sm-6 p-1">
                    <div className="card bannercard">
                        <img className="card-img-top cover" src={sofaBook} alt="Card image cap" height="200" width="117"/>            
                    </div>
                </div>
                <div className="col-lg-6 col-md-6 c0l-sm-6 p-1">
                    <div className="card bannercard">
                        <img className="card-img-top cover" src={everybook} alt="Card image cap" height="200"/>            
                    </div>
                </div>
            </div>
            <hr></hr>
            <div className="row">
                <div className="col-lg-6 col-md-6 col-sm-6">
                    <div className="row">
                        <div className="col-lg-4 col-md-4 p-1">
                            <div className="card bannercard">
                                <img className="card-img-top cover authorimg" src={chetan} alt="Card image cap" height="200"/>            
                            </div>
                        </div>
                        <div className="col-lg-4 col-md-4 p-1">
                            <div className="card bannercard">
                                <img className="card-img-top cover authorimg" src={jkrowling} alt="Card image cap" height="200"/>            
                            </div>
                        </div>
                        <div className="col-lg-4 col-md-4 p-1">
                            <div className="card bannercard">
                                <img className="card-img-top cover authorimg" src={pauloCoelho} alt="Card image cap" height="200"/>            
                            </div>
                        </div>
                    </div>
                </div>
                <div className="col-lg-6 col-md-6 col-sm-6">
                    <div className="row">
                        <div className="col-lg-4 col-md-4 p-1">
                            <div className="card bannercard">
                                <img className="card-img-top cover authorimg" src={bookGenres} alt="Card image cap" height="200"/>            
                            </div>
                        </div>
                        <div className="col-lg-4 col-md-4 p-1">
                            <div className="card bannercard">
                                <img className="card-img-top cover authorimg" src={webd} alt="Card image cap" height="200"/>            
                            </div>
                        </div>
                        <div className="col-lg-4 col-md-4 p-1">
                            <div className="card bannercard">
                                <img className="card-img-top cover authorimg" src={science} alt="Card image cap" height="200"/>            
                            </div>
                        </div>
                    </div>
                </div>
            </div>  
            <hr></hr>          
            </>
        )
    }
}

